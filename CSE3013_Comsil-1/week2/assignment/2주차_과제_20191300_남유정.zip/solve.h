#include "calc.h"

void solve(int A, int B, int d,int *arr);