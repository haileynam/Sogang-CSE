﻿#pragma warning(disable: 4996)
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define FOR(i,n)    for(int i=0;i<n;i++)

typedef struct {
	unsigned long long int weight;
	int u;
	int v;
}edge;

typedef struct {
	int V;
	unsigned long long int E;
}Graph;

typedef struct {
	int parent;
	int rank;
	unsigned long long int weight;
	unsigned long long int vertex_cnt;
}DisjointSet;

Graph g;
int kscanned = 0;
void adjust(edge* heap, int root, int n);
void make_heap(edge* heap);
edge delete_heap(edge* heap);
int set_find(DisjointSet* DS, int v);
void set_union(DisjointSet* DS, int u, int v, unsigned long long int w);
void set_init(DisjointSet* DS);
long long int kruskal(DisjointSet* DS, edge* heap);
unsigned long long int heap_size = 0;

int main() {
	char str[255] = "Graphs_HW4\\";
	int num = 0, j = 0;
	clock_t start, end1, end2;
	float res1, res2;

	FILE* commandfp = fopen("Graphs_HW4\\commands.txt", "r");
	if (commandfp == NULL) {
		printf("The input file1 dose not exist.\n");
		exit(1);
	}

	fscanf(commandfp, "%s", str + 11);
	FILE* infp = fopen(str, "r");
	if (infp == NULL) {
		printf("The input file2 dose not exist.\n");
		exit(1);
	}
	printf("Opened file: %s\n", str);

	fscanf(commandfp, "%s", str + 11);
	FILE* outfp = fopen(str, "w");
	if (outfp == NULL) {
		printf("The input file3 dose not exist.\n");
		exit(1);
	}

	fclose(commandfp);
	unsigned long long int MAX_WEIGHT;
	fscanf(infp, "%d %lld %lld", &g.V, &g.E, &MAX_WEIGHT);
	printf("%d %lld %lld\n", g.V, g.E, MAX_WEIGHT);
	edge* min_heap = (edge*)malloc(sizeof(edge) * (g.E + 1));
	int fromId, toId, ftot;
	DisjointSet* v = (DisjointSet*)malloc(sizeof(DisjointSet) * g.V);
	FOR(i, g.E) {	//O(lEl)
		edge e;
		fscanf(infp, "%d %d %lld", &e.u, &e.v, &e.weight);

		min_heap[i + 1] = e;
		heap_size++;
	}

	start = clock();
	make_heap(min_heap);	//O(|E|)
	end1 = clock();

	set_init(v);
	/*FOR(i, g.V)
	{
		v->parent = i;
		v->rank = 0;
		v->vertex_cnt = 1;
		v->weight = 0;
	}*/

	int cnt_edge = kruskal(v, min_heap);	//O(|E|log|V|)
	num = g.V - cnt_edge;
	DisjointSet* result = (DisjointSet*)malloc(sizeof(DisjointSet) * num);
	FOR(i, g.V) {	//O(|V|)
		if (v[i].parent == i) {
			result[j].vertex_cnt = v[i].vertex_cnt;
			result[j].weight = v[i].weight;
			j++;
			if (j == num)
				break;
		}
	}
	end2 = clock();

	res1 = (float)(end1 - start) / CLOCKS_PER_SEC;
	res2 = (float)(end2 - start) / CLOCKS_PER_SEC;
	printf("kscanned: %d\n", kscanned);
	printf("%.3f(%.3f)\n%d\n", res2, res1, num);

	fprintf(outfp, "%d\n", num);
	FOR(i, num) {	//O(|V|);
		fprintf(outfp, "%lld %lld\n", result[i].vertex_cnt, result[i].weight);
		printf("%lld %lld\n", result[i].vertex_cnt, result[i].weight);

	}

	fclose(infp);
	fclose(outfp);
	free(min_heap);
	free(v);
	free(result);

	return 0;
}

void adjust(edge* heap, int i, int n) {
	int child, root;
	root = heap[i].weight;
	edge e = heap[i];
	child = 2 * i;
	while (child <= n) {
		if ((child < n) && (heap[child].weight > heap[child + 1].weight))
			child++;
		if (root <= heap[child].weight)
			break;
		else {
			heap[child / 2] = heap[child];
			child *= 2;
		}
	}
	heap[child / 2] = e;
}

void make_heap(edge* heap) {
	for (int i = heap_size / 2; i > 0; i--) {
		adjust(heap, i, heap_size);
	}
}

edge delete_heap(edge* heap) {
	edge e, temp;
	e.u = heap[1].u;
	e.v = heap[1].v;
	e.weight = heap[1].weight;

	temp = heap[1];
	heap[1] = heap[heap_size];
	heap[heap_size] = temp;
	heap_size--;
	adjust(heap, 1, heap_size);

	return e;
}

int set_find(DisjointSet* DS, int v) {
	if (v != DS[v].parent)
		DS[v].parent = set_find(DS, DS[v].parent);

	return DS[v].parent;
}

void set_union(DisjointSet* DS, int u, int v, unsigned long long int w) {
	if (u == v)
		return;

	if (DS[u].rank >= DS[v].rank) {
		if (DS[u].rank == DS[v].rank)
			DS[u].rank++;
		DS[v].parent = u;
		DS[u].vertex_cnt += DS[v].vertex_cnt;
		DS[u].weight += DS[v].weight + w;
	}
	else {
		DS[u].parent = v;
		DS[v].vertex_cnt += DS[u].vertex_cnt;
		DS[v].weight += DS[u].weight + w;
	}

}

void set_init(DisjointSet* DS) {
	FOR(i, g.V) {
		DS[i].parent = i;
		DS[i].rank = 0;
		DS[i].vertex_cnt = 1;
		DS[i].weight = 0;
	}
}

long long int kruskal(DisjointSet* DS, edge* heap) {
	int cnt_edge = 0;
	while (cnt_edge < g.V - 1) {
		kscanned++;
		edge e = delete_heap(heap);
		int x = set_find(DS, e.u);
		int y = set_find(DS, e.v);
		if (x != y) {
			set_union(DS, x, y, e.weight);
			cnt_edge++;
		}
		if (heap_size == 0)
			break;
	}
	return cnt_edge;
}