#pragma warning (disable: 4996)
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_map>
#define FOR(i,n)    for(int i=0;i<n;i++)
using namespace std;

int a, b, c, d;
int* makeArray(int x)
{
    int* ret = (int*)malloc(x * sizeof(int));
    FOR(i, x)
        ret[i] = 0;
    return ret;
}

void printArray(int* X)
{
    for (int i = 0; i < (sizeof(X) / sizeof(X[0])); i++)
        cout << X[i];
    cout << endl;
}

//int isShuffle(int* x, int* y, int* z, int n, int m, int r) 
//{
//    if (r != n + m)
//        return 0; // obvious case
//    int** S = (int**)calloc((n + 1), sizeof(int));
//    for (int i = 0; i <= n; i++)
//        S[i] = (int*)calloc((m + 1), sizeof(int));
//    S[0][0] = 1;
//    for (int i = 1; i <= n; i++)
//    {
//        if (S[i - 1][0] == 1 && (z[i - 1] == x[i - 1]))
//            S[i][0] = 1;
//        else S[i][0] = 0;
//    }
//       
//    for (int j = 1; j <= m; j++)
//    {
//        if (S[0][j - 1] == 1 && (z[j - 1] == y[j - 1]))
//            S[0][j] = 1;
//        else S[0][j] = 0;
//    }
//       
//
//    for (int i = 1; i <= n; i++)
//        for (int j = 1; j <= m; j++) {
//            if (((z[i + j - 1] == x[i - 1]) && S[i - 1][j] == 1) || ((z[i + j - 1] == y[j - 1]) && S[i][j - 1] == 1))
//                S[i][j] = 1;
//            else S[i][j] = 0;
//        }
//
//    for (int i = 0; i <= n; i++) {
//        for (int j = 0; j <= m; j++) cout << S[i][j] << ' ';
//        cout << endl;
//    }
//    
//    return S[n][m];
//    free(S);
//}

bool isShuffle(int* x, int* y, int* z, int n, int m, int r) {

    if (r != n + m)
        return false; // obvious case
    bool** S = (bool**)malloc(sizeof(bool*) * (n + 1));
    for (int i = 0; i <= n; i++)
        S[i] = (bool*)malloc(sizeof(bool) * (m + 1));

    S[0][0] = true;
    for (int i = 1; i <= n; i++)
        S[i][0] = S[i - 1][0] && (z[i - 1] == x[i - 1]);
    for (int j = 1; j <= m; j++)
        S[0][j] = S[0][j - 1] && (z[j - 1] == y[j - 1]);

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            S[i][j] = ((z[i + j - 1] == x[i - 1]) && S[i - 1][j])
                || ((z[i + j - 1] == y[j - 1]) && S[i][j - 1]);
        }

    /*for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) cout << S[i][j] << ' ';
        cout << '\n';
    }*/
    bool ret =S[n][m];
    free(S);
    return ret;
}

int main()
{
    FILE* command = fopen("commands_3_2.txt", "r");
    char tmp; int lineCnt = 1; 
    while (fscanf(command, "%c", &tmp) != EOF)
    {
        if (tmp == '\n')
            lineCnt++;
    }
    cout << "Linecount: " << lineCnt << endl;
    fseek(command, 0, SEEK_SET);
    FILE* output = fopen("output_3_2.txt", "w");
    for (int i = 0; i < lineCnt; i++)
    {
        char inputFile[50] = { 0, };
        fgets(inputFile, 50, command);
        if (i < lineCnt - 1)
            inputFile[strlen(inputFile) - 1] = '\0';
        cout << inputFile << endl;
        FILE* input = fopen(inputFile, "r");
        fscanf(input, "%d", &a);
        cout << "a: " << a << endl;
        int* A = makeArray(a);
        FOR(i, a)
            fscanf(input, "%d", &A[i]);
        FOR(i, a)
            cout << A[i];
        cout << endl;
        fscanf(input, "%d", &b);
        cout << "b: " << b << endl;
        int* B = makeArray(b);
        FOR(i, b)
            fscanf(input, "%d", &B[i]);
        FOR(i, b)
            cout << B[i];
        cout << endl;
        fscanf(input, "%d", &c);
        cout << "c: " << c << endl;
        int* C = makeArray(c);
        FOR(i, c)
            fscanf(input, "%d", &C[i]);
        FOR(i, c)
            cout << C[i];
        cout << endl;
        fscanf(input, "%d", &d);
        cout << "d: " << d << endl;
        int* D = makeArray(d);
        FOR(i, d)
            fscanf(input, "%d", &D[i]);
        FOR(i, d)
            cout << D[i];
        cout << endl;
        
        if (isShuffle(A, B, C, a, b, c))
        {
            fprintf(output, "%d", 1);
            printf("true\n");
        }
        else
        {
            fprintf(output, "%d", 0);
            printf("false\n");
        }
        if (isShuffle(A, B, D, a, b, d))
        {
            fprintf(output, "%d", 1);
            printf("true\n");
        }
        else
        {
            fprintf(output, "%d", 0);
            printf("false\n");
        }
        fprintf(output, "%c", '\n');
        free(A);
        free(B);
        free(C);
        free(D);
        fclose(input);
    }
    fclose(output);
    return 0;
}