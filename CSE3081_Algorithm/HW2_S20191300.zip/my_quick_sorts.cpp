#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <stack>

using namespace std;

#define INSERT 200
#define swap(a, b, type) \
    do                   \
    {                    \
        type temp;       \
        temp = a;        \
        a = b;           \
        b = temp;        \
    } while (0)

typedef struct
{
    unsigned int score;
    float data[3];
    char comments[16];
} ELEMENT;

typedef int _Cmpfun(const void*, const void*);

int partition(void* base, int left, int right)
{
    ELEMENT* buffer = (ELEMENT*)base;
    int p_val = left;
    int idx = p_val;
    for (int i = left + 1; i <= right; i++)
    {
        if (buffer[p_val].score > buffer[i].score)
        {
            idx++;
            swap(buffer[i], buffer[idx], ELEMENT);
        }
    }
    swap(buffer[p_val], buffer[idx], ELEMENT);
    p_val = idx;

    return p_val;
}

size_t median_of_three(void* base, size_t left_index, size_t right_index)
{
    ELEMENT* buffer = (ELEMENT*)base;
    size_t median_index = (left_index + (right_index - left_index)) / 2;
    int sample[3] = { left_index, median_index, right_index };

    /* left - median compariaon */
    if (buffer[sample[0]].score > buffer[sample[1]].score)
        swap(buffer[sample[0]], buffer[sample[1]], ELEMENT);
    /* median - right comparison */
    if (buffer[sample[1]].score > buffer[sample[2]].score)
        swap(buffer[sample[1]], buffer[sample[2]], ELEMENT);
    /* left - median comparison */
    if (buffer[sample[0]].score > buffer[sample[1]].score)
        swap(buffer[sample[0]], buffer[sample[1]], ELEMENT);

    return sample[1];
}

int partition_mot(void* base, int left, int right)
{
    ELEMENT* buffer = (ELEMENT*)base;
    int p_val = median_of_three(base, left, right);
    int idx = p_val;
  
    for (int i = left; i <= right; i++)
    {
        if (buffer[p_val].score > buffer[i].score)
        {
            idx++;
            swap(buffer[i], buffer[idx], ELEMENT);
        }
    }
    swap(buffer[p_val], buffer[idx], ELEMENT);
    p_val = idx;

    return p_val;
}

void threesort(void* base, int left_index, int right_index)
{
    ELEMENT* buffer = (ELEMENT*)base;
    size_t median_index = (left_index + (right_index - left_index)) / 2;
    int sample[3] = { left_index, median_index, right_index };

    /* left - median compariaon */
    if (buffer[sample[0]].score > buffer[sample[1]].score)
        swap(buffer[sample[0]], buffer[sample[1]], ELEMENT);
    /* median - right comparison */
    if (buffer[sample[1]].score > buffer[sample[2]].score)
        swap(buffer[sample[1]], buffer[sample[2]], ELEMENT);
    /* left - median comparison */
    if (buffer[sample[0]].score > buffer[sample[1]].score)
        swap(buffer[sample[0]], buffer[sample[1]], ELEMENT);
}

void qsort_as_original(void* base, size_t n, size_t size, _Cmpfun* CMPFunc)
{
    ELEMENT* buffer = (ELEMENT*)base;
    int left_index = 0;
    int right_index = n - 1;
    int cookie;
    if (left_index < right_index) {
        //printf("!!\n");
        cookie = partition((void*)buffer, left_index, right_index);
        //printf("cookie: %d\n", cookie);
        qsort_as_original((void*)buffer, cookie, size, CMPFunc);
        qsort_as_original((void*)(buffer + (cookie + 1)), n - cookie - 1, size, CMPFunc);
    }
    else return;
}

void insertion_sort(void* base, unsigned int left_index, unsigned right_index)
{
    ELEMENT* buffer = (ELEMENT*)base;
    int n = right_index - left_index + 1;
    unsigned int tmp;
    for (int i = left_index; i < right_index; i++)
    {
        for (int j = i + 1; j > 0; j--)
        {
            if (buffer[j].score < buffer[j - 1].score) {
                tmp = buffer[j - 1].score;
                buffer[j - 1] = buffer[j];
                buffer[j].score = tmp;
            }
            else
                break;
        }

    }

    return;
}


void qsort_median_insert(void* base, size_t n, size_t size, _Cmpfun* cmp)
{
    ELEMENT* buffer = (ELEMENT*)base;
    const size_t left_index = 0,
        mid_index = (n - 1) / 2,
        right_index = n - 1;

    if ((right_index - left_index) < INSERT)
    {
        //printf("insertion sort\n");
        insertion_sort(buffer, left_index, right_index);
    }
    else
    {
        threesort(base, left_index, right_index);
        if (right_index - left_index + 1 > 3)
        {
            int pivot = buffer[mid_index].score;
            swap(buffer[mid_index], buffer[right_index - 1], ELEMENT);
            int i = left_index; int j = right_index - 1;
            while (1)
            {
                while (buffer[++i].score < pivot && i < right_index);
                while (buffer[--j].score > pivot && j > left_index);
                if (i >= j)break;
                swap(buffer[i], buffer[j], ELEMENT);
            }
            swap(buffer[i], buffer[right_index - 1], ELEMENT);
            qsort_median_insert((void*)buffer, i - 1, size, cmp);
            qsort_median_insert((void*)(buffer + i), n- i, size, cmp);
        }
    }
}

void qsort_median_insert_iter(void* base, size_t n, size_t size, _Cmpfun* cmp)
{
    ELEMENT* buffer = (ELEMENT*)base;
    const size_t left_index = 1,
        mid_index = n / 2,
        right_index = n - 1;

    /* ���� ũ�Ⱑ INSERT �̸��� ��� */
    if ((right_index - left_index) < INSERT)
    {
        insertion_sort(buffer, left_index, right_index);
    }
    else
    {
        size_t pivot = median_of_three((void*)buffer, left_index, right_index);

        if ((pivot) < (n - pivot - 1))
        { // ó��~pivot < pivot+1~��
            qsort_median_insert_iter((void*)buffer, pivot + 1, size, cmp);
        }
        else
        {
            // int stack[pivot];
            int* stack = (int*)calloc(pivot, sizeof(int));
            int h, l;
            int top = -1;

            stack[++top] = 0;
            stack[++top] = pivot - 1;

            h = pivot - 1;
            l = 0;

            while (top >= 0)
            {
                h = stack[top--];
                l = stack[top--];

                size_t p = partition((void*)stack, l, h);

                if (p - 1 > l)
                {
                    stack[++top] = l;
                    stack[++top] = p - 1;
                }

                if (p + 1 < h)
                {
                    stack[++top] = p + 1;
                    stack[++top] = h;
                }
            }
        }
    }
}