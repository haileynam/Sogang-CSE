#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    unsigned int score;
    float data[3];
    char comments[16];
} ELEMENT;

typedef int (_Cmpfun)(const void*, const void*);
size_t partition(void* base, int p, int r);
void qsort_as_original(void* base, size_t left_index, size_t right_index, _Cmpfun* CMPFunc);
void insertion_sort(void* base, unsigned int left_index, unsigned right_index);
size_t median_of_three(void* base, size_t left_index, size_t right_index);
void qsort_median_insert(void* base, size_t n, size_t size, _Cmpfun* cmp);
void qsort_median_insert_iter(void* base, size_t n, size_t size, _Cmpfun* cmp);
void threesort(void* base, size_t left_index, size_t right_index);