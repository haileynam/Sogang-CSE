#pragma warning(disable: 4996)
#include <iostream>
#include <string>

using namespace std;
#define FOR(i,n)   for(int i=0;i<n;i++)
#define FOR1(i,n)   for(int i=1;i<=n;i++)
#define endl   '\n'
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

typedef pair<int, int> ii;

string lcs(string & X, string & Y)
{
	int m = X.length();
	int n = Y.length();
	int** L = (int**)malloc(sizeof(int) * (m + 1));
	FOR(i, n + 1)
		L[i] = (int*)malloc(sizeof(int) * (n + 1));
	//initialize
	FOR(i, m + 1)
	{
		FOR(j, n + 1)
		{
			L[i][j] = 0;
		}
	}

	/* Following steps build L[m+1][n+1] in bottom
	   up fashion. Note that L[i][j] contains
	   length of LCS of X[0..i-1] and Y[0..j-1] */
	for (int i = 0; i <= m; i++)
	{
		for (int j = 0; j <= n; j++)
		{
			if (i == 0 || j == 0)
				L[i][j] = 0;
			else if (X[i - 1] == Y[j - 1])
				L[i][j] = L[i - 1][j - 1] + 1;
			else
				L[i][j] = max(L[i - 1][j], L[i][j - 1]);
		}
	}

	int index = L[m][n];

	string lcs(index + 1, '\0');

	int i = m, j = n;
	while (i > 0 && j > 0)
	{
		if (X[i - 1] == Y[j - 1])
		{
			lcs[index - 1] = X[i - 1];
			i--;
			j--;
			index--;
		}

		else if (L[i - 1][j] > L[i][j - 1])
			i--;
		else
			j--;
	}
	return lcs;
}

void LPS(const int m, const char* X, int* LPS_length, char** LPS_string)
{
	string str = string(X);
	string rev = string(X);
	reverse(rev.begin(), rev.end());
	/*cout << "str is " << str << endl;
	cout << "rev is " << rev << endl;*/
	string lps = lcs(str, rev);
	cout << "LPS is " << endl;
	cout << lps << endl;
	cout << "LPS length is" << endl;
	cout << lps.length()-1 << endl;
	char* str2char = (char*)malloc(sizeof(char) * lps.length() - 1);
	FOR(i, lps.length() - 1)
		str2char[i] = lps[i];
	cout << "test: " << endl;
	FOR(i, lps.length() - 1)
		cout << str2char[i];
	cout << endl;
	cout << "testend" << endl;
	*LPS_length = (lps.length() - 1);
	*LPS_string = str2char;
}

int main()
{
	int n = 0;
	int  m = 0;
	FILE* input = fopen("config_LPS.txt", "r");
	char X[256] = {0,};
	//cin >> n;
	fscanf(input, "%d", &n);
	cout << "n: " << n << endl;
	// delete '\n'
	char trash = NULL;
	fscanf(input, "%c", &trash);
	int cnt = 0;
	
	FOR(i, n)
	{
		int LPS_length = NULL;
		char* LPS_string = NULL;
		char input_filename[50] = {0,};
		char output_filename[50] = {0,};
			
		char* pinput_filename = fgets(input_filename, 50, input);
		input_filename[strlen(input_filename) - 1] = '\0';
		char* poutput_filename = fgets(output_filename, 50, input);
		output_filename[strlen(output_filename) - 1] = '\0';
		cout << "input filename: " << input_filename << endl;
		cout << "output filename: " << output_filename << endl;

		FILE* open = fopen(input_filename, "rb");
		fread(&m, sizeof(int), 1,open);
		//cout << "m:" << m;

		FOR(i, m)
		{
			//cin >> X[i];
			fread(&X[i], sizeof(char), 1, open);
		}

		fclose(open);
		//cout << "input end" << endl;
		FILE* output = fopen(output_filename, "wb");
		LPS(m, X, &LPS_length, &LPS_string);
		cout << "LPS length: " << LPS_length << endl;
		cout << "LPS string: " << endl;
		FOR(i, LPS_length)
			cout << LPS_string[i];
		//fprintf(output, "%d", LPS_length);
		fwrite(&LPS_length, sizeof(LPS_length), 1, output);
		fflush(output);
		FOR(i, LPS_length)
			fprintf(output, "%c", LPS_string[i]);
		fclose(output);
	}

	fclose(input);
	return 0;
}

