#pragma warning (disable: 4996)
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_map>
using namespace std;

#define MAX_TREE_HT 9999

int idx_num ;

struct Three {
	char x;
	int* y;
	double z;
};

vector<struct Three> myvec(idx_num, {0, 0, 0});

struct MinHeapNode {

	char data;

	double freq;

	struct MinHeapNode* left, * right;
};

struct MinHeap {

	unsigned size;

	unsigned capacity;

	struct MinHeapNode** array;
};

struct MinHeapNode* newNode(char data, double freq)
{
	struct MinHeapNode* temp = (struct MinHeapNode*)malloc(sizeof(struct MinHeapNode));

	temp->left = NULL;
	temp->right = NULL;
	temp->data = data;
	temp->freq = freq;

	return temp;
}


struct MinHeap* createMinHeap(unsigned capacity)
{
	struct MinHeap* minHeap = (struct MinHeap*)malloc(sizeof(struct MinHeap));

	// current size is 0
	minHeap->size = 0;

	minHeap->capacity = capacity;

	minHeap->array = (struct MinHeapNode**)malloc(minHeap->capacity * sizeof(struct MinHeapNode*));
	return minHeap;
}

void swapNode(struct MinHeapNode** a,
	struct MinHeapNode** b)
{
	struct MinHeapNode* t = *a;
	*a = *b;
	*b = t;
}

void minHeapify(struct MinHeap* minHeap, int idx)
{
	int parent = idx;
	int left = 2 * idx + 1;
	int right = 2 * idx + 2;

	if (left < minHeap->size && minHeap->array[left]->freq < minHeap->array[parent]->freq)
		parent = left;

	if (right < minHeap->size && minHeap->array[right]->freq < minHeap->array[parent]->freq)
		parent = right;

	if (parent != idx) {
		swapNode(&minHeap->array[parent], &minHeap->array[idx]);
		minHeapify(minHeap, parent);
	}
}

bool isSizeOne(struct MinHeap* minHeap)
{
	if (minHeap->size == 1)
		return true;
	else return false;
}

// Common logic.. 
struct MinHeapNode* extractMin(struct MinHeap* minHeap)
{

	struct MinHeapNode* temp = minHeap->array[0];
	// last one goes to root
	minHeap->array[0] = minHeap->array[minHeap->size - 1];

	--minHeap->size;
	minHeapify(minHeap, 0);

	return temp;
}

void insertMinHeap(struct MinHeap* minHeap, struct MinHeapNode* minHeapNode)
{
	++minHeap->size;
	int i = minHeap->size - 1;

	while (i && minHeapNode->freq < minHeap->array[(i - 1) / 2]->freq) {
		minHeap->array[i] = minHeap->array[(i) / 2];
		i = (i) / 2;
	}

	minHeap->array[i] = minHeapNode;
}

// A standard function to build min heap
void buildMinHeap(struct MinHeap* minHeap)
{
	int n = minHeap->size - 1;
	int i;

	for (i = (n - 1) / 2; i >= 0; --i)
		minHeapify(minHeap, i);
}

void printArr(int arr[], int n)
{
	int i;
	for (i = 0; i < n; ++i)
	{
		cout << arr[i];
		//huffcode[i] = arr[i];
	}
}

int* getArr(int arr[], int n)
{
	int* retArr = (int*)malloc(sizeof(int)* n);
	for (int i = 0; i < n; ++i)
	{
		arr[i] = retArr[i];
	}
	return retArr;
}

int isLeaf(struct MinHeapNode* root)
{
	return !(root->left) && !(root->right);
}

struct MinHeap* createAndBuildMinHeap(char data[], double freq[], int size)
{
	struct MinHeap* minHeap = createMinHeap(size);

	for (int i = 0; i < size; ++i)
		minHeap->array[i] = newNode(data[i], freq[i]);

	minHeap->size = size;
	buildMinHeap(minHeap);

	return minHeap;
}

struct MinHeapNode* buildHuffmanTree(char data[], double freq[], int size)

{
	struct MinHeapNode* left, * right, * newParent;

	//Min heap with string size
	struct MinHeap* minHeap = createAndBuildMinHeap(data, freq, size);

	// Iterate while size of heap doesn't become 1
	while (!isSizeOne(minHeap)) {

		// two minimum character out
		left = extractMin(minHeap);
		right = extractMin(minHeap);

		// make new node with sum of frequency
		newParent = newNode('*', left->freq + right->freq);
		newParent->left = left;
		newParent->right = right;

		insertMinHeap(minHeap, newParent);
	}

	// it becomes root
	return extractMin(minHeap);
}
string int2string(int arr[],int n)
{
	string str;
	for (int i = 0; i < n; i++)
		str += to_string(arr[i]);
	return str;
}

void returnCodes(vector<Three> v)
{
	for (int i = 0; i < idx_num; i++)
		cout << v[i].x << " " << v[i].y << " " << v[i].z << endl;
	cout << endl;
}

bool comparebyascii(const Three &a, const Three &b)
{
	return (int)a.x < (int)b.x;
}
int vec_size = 0;

// Prints huffman codes from the root of Huffman Tree.
void printCodes(struct MinHeapNode* root, int arr[], int top)
{
	struct Three myvecElem;
	// Assign 0 to left edge and recur
	if (root->left) 
	{
		arr[top] = 0;
		printCodes(root->left, arr, top + 1);
	}

	// Assign 1 to right edge and recur
	if (root->right) 
	{
		arr[top] = 1;
		printCodes(root->right, arr, top + 1);
	}

	// If this is a leaf node, then
	// it contains one of the input
	// characters, print the character
	// and its code from arr[]
	if (isLeaf(root)) {

		cout << "top: " << top << endl;
		int* b = NULL;
		b = (int*)malloc(sizeof(int) * top);
		if(top!=0)
			cout << "B size: " << _msize(b)<<" ";
		cout << root->data << " ";

		for (int i = 0; i < top; i++)
		{
			cout << arr[i];
			//b[i] = arr[i];
			
		}
		memcpy(b, arr, top*4);
		cout << " ";
		for (int i = 0; i < (_msize(b) / 4); i++)
			cout << b[i];
		
		cout<<fixed;
		cout.precision(2);
		cout << " " << root->freq<<" ";
		
		myvecElem.x = root->data;
		myvecElem.y = b;
		myvecElem.z= root->freq;
		/*for (int i = 0; i < _msize(myvecElem.y) / 4; i++)
			cout << myvecElem.y[i];*/
		cout << endl;
		myvec.push_back(myvecElem);
		vec_size++;
		//free(b);
	}
}

// The main function that builds a
// Huffman Tree and print codes by traversing
// the built Huffman Tree
void HuffmanCodes(char data[], double freq[], int size)
{
	// Construct Huffman Tree
	struct MinHeapNode* root = buildHuffmanTree(data, freq, size);

	// Print Huffman codes using
	// the Huffman tree built above
	int arr[MAX_TREE_HT], top = 0;

	printCodes(root, arr, top);
}


int main()
{
	FILE* input = fopen("P3_input_ASCII.txt", "r");
	char str[2000];
	fgets(str, 2000, input);
	//str[strlen(str) - 1] = '\0';
	string s(str);
	cout << s << endl;
	//cout << "enter s" << endl;
	//getline(cin, s);
	//sort(s.begin(), s.end());
	
	unordered_map<char, int> d;
	char c[128] = {};
	char c2[128] = {};
	int freq[128];
	double freq2[128];
	for (char i : s)
		d[i]++;

	for (char i : s)
		if (d[i] != 0)
		{
			//cout << i << d[i] << " "; i: char d[i]: times
			c[(int)i] = i;
			freq[(int)i] = d[i];
			d[i] = 0;
		}
	/*cout << "c array: " << endl;
	for (int i = 0; i < 128; i++)
	{
		if (c[i]!=NULL)
			cout << c[i] << " ";
	}
	cout << endl;*/

	// Non-existing ascii character, delete
	idx_num = 0;
	for (int i = 0; i < 128; i++)
	{
		if (c[i] != NULL)
		{
			c2[idx_num] = c[i];
			freq2[idx_num] = (100.0 * freq[i])/s.length();
			idx_num++;
		}
	}
	/*for (int i = 0; i < idx_num; i++)
	{
		cout << fixed;
		cout.precision(2);
		cout << c2[i] << " " << freq2[i] << endl;
	}*/
	
	cout << "Huffman" << endl;
	HuffmanCodes(c2, freq2, idx_num);
	for (int i = 0; i < idx_num; i++)
	{
		cout << myvec[i].x << " ";
		for (int j = 0; j < _msize(myvec[i].y) / 4; j++)
			cout << myvec[i].y[j];
		cout << " " << myvec[i].z << endl;
	}
	sort(myvec.begin(), myvec.end(), comparebyascii);
	cout << "after sort" << endl;
	//cout << "Myvec size: " << vec_size << endl;
	for (int i = 0; i < idx_num; i++)
	{
		cout << myvec[i].x << " ";
		for (int j = 0; j < _msize(myvec[i].y)/4; j++)
		{
			
			cout << myvec[i].y[j];
			
		}
		cout << " " << myvec[i].z << endl;
	}
	//FILE* entxt = fopen("encode.txt", "w");
	FILE* enbin = fopen("encode.bin", "wb");
	cout << "huffman encode: " << endl;
	for (int i = 0; i < s.length(); i++) {
		for (int j = 0; j < idx_num; j++)
		{
			if (myvec[j].x == s[i]) {
				for (int k = 0; k < _msize(myvec[j].y)/4; k++)
				{
					/*if (myvec[j].y[k] < 0 || myvec[j].y[k]>1)
						break;*/
					cout << myvec[j].y[k];
					//fprintf(entxt, "%d", myvec[j].y[k]);
					fwrite(&myvec[j].y[k], sizeof(int), 1, enbin);
				}
			}
		}
	}

	cout << endl;
	FILE* fp = fopen("P3_output_codewords.txt", "w");
	while (!myvec.empty())
	{
		fprintf(fp, "%c ", myvec.front().x);
		
		for (int i = 0; i < sizeof(myvec.front().y); i++)
		{
			if (myvec.front().y[i]<0||myvec.front().y[i]>1)
				break;
			fprintf(fp, "%d", myvec.front().y[i]);
		}
		fprintf(fp, " %.2lf\n", myvec.front().z);
		myvec.erase(myvec.begin());

	}
	
	
	return 0;
}
